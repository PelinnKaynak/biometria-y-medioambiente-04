# Diseño de el modelo de previsión de ozono (IA)

## Diseño del componente

_Pendiente._ Aquí va el diseño técnico siguiendo la notación de la asignatura.

Contenido esperado: Datos de entrada (estaciones oficiales y AEMET), preparación de los datos, variables del modelo, entrenamiento, evaluación y cómo se usa la previsión desde el servidor.

## Aclaraciones del diseño

_Pendiente._ Decisiones o matices del diseño que no se ven a simple vista. Si no hace falta ninguna, se puede borrar esta sección.

## Reglas generales

- Lenguaje de programación: Python con pandas y scikit-learn.
- El encabezado de cada función o método incluye su diseño lógico dentro de un bloque de comentarios delimitado por líneas discontinuas (`--------------------`).
- El código debe ser lo más claro posible, de forma que casi no necesite comentarios adicionales.
- Se generan pruebas unitarias o de integración para todas las funciones y métodos importantes. Las pruebas se hacen con pytest.
- No se añaden funcionalidades que no estén en este diseño ni se cambia la arquitectura del sistema.
