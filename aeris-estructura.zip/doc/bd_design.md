# Diseño de la base de datos

## Diseño del componente

_Pendiente._ Aquí va el diseño técnico siguiendo la notación de la asignatura.

Contenido esperado: Tablas, campos, tipos, claves primarias y ajenas y restricciones, siguiendo el diseño de la base de datos en Figma.

## Aclaraciones del diseño

_Pendiente._ Decisiones o matices del diseño que no se ven a simple vista. Si no hace falta ninguna, se puede borrar esta sección.

## Reglas generales

- Lenguaje de programación: SQL para MySQL.
- El encabezado de cada función o método incluye su diseño lógico dentro de un bloque de comentarios delimitado por líneas discontinuas (`--------------------`).
- El código debe ser lo más claro posible, de forma que casi no necesite comentarios adicionales.
- Se generan pruebas unitarias o de integración para todas las funciones y métodos importantes. Las pruebas comprueban la creación de las tablas y las consultas principales con datos de prueba.
- No se añaden funcionalidades que no estén en este diseño ni se cambia la arquitectura del sistema.
