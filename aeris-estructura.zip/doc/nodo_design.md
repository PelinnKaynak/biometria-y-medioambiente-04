# Diseño de el firmware del nodo sensor

## Diseño del componente

_Pendiente._ Aquí va el diseño técnico siguiendo la notación de la asignatura.

Contenido esperado: Qué mide el sensor, cada cuánto, cómo se calibra la lectura y qué datos se envían por Bluetooth LE (formato del anuncio o de la característica).

## Aclaraciones del diseño

_Pendiente._ Decisiones o matices del diseño que no se ven a simple vista. Si no hace falta ninguna, se puede borrar esta sección.

## Reglas generales

- Lenguaje de programación: C++ para Arduino (placa SparkFun nRF52840).
- El encabezado de cada función o método incluye su diseño lógico dentro de un bloque de comentarios delimitado por líneas discontinuas (`--------------------`).
- El código debe ser lo más claro posible, de forma que casi no necesite comentarios adicionales.
- Se generan pruebas unitarias o de integración para todas las funciones y métodos importantes. Las pruebas se hacen con una placa real o con funciones de prueba que simulan la lectura del sensor.
- No se añaden funcionalidades que no estén en este diseño ni se cambia la arquitectura del sistema.
