# Diseño de el panel de administración web

## Diseño del componente

_Pendiente._ Aquí va el diseño técnico siguiendo la notación de la asignatura.

Contenido esperado: Pantallas del panel (nodos, usuarios, histórico, campañas y zonas sensibles), lógica fake y real del navegador y control de acceso por rol.

## Aclaraciones del diseño

_Pendiente._ Decisiones o matices del diseño que no se ven a simple vista. Si no hace falta ninguna, se puede borrar esta sección.

## Reglas generales

- Lenguaje de programación: HTML, CSS y JavaScript sin frameworks.
- El encabezado de cada función o método incluye su diseño lógico dentro de un bloque de comentarios delimitado por líneas discontinuas (`--------------------`).
- El código debe ser lo más claro posible, de forma que casi no necesite comentarios adicionales.
- Se generan pruebas unitarias o de integración para todas las funciones y métodos importantes. Las pruebas se hacen con Jest.
- No se añaden funcionalidades que no estén en este diseño ni se cambia la arquitectura del sistema.
