# Diseño de la lógica de negocio del servidor

## Diseño del componente

_Pendiente._ Aquí va el diseño técnico siguiendo la notación de la asignatura.

Contenido esperado: Funciones de la lógica de negocio, qué validan y qué devuelven. No accede a HTTP: la llama el servidor REST y ella llama a la base de datos.

## Aclaraciones del diseño

_Pendiente._ Decisiones o matices del diseño que no se ven a simple vista. Si no hace falta ninguna, se puede borrar esta sección.

## Reglas generales

- Lenguaje de programación: JavaScript con Node.js.
- El encabezado de cada función o método incluye su diseño lógico dentro de un bloque de comentarios delimitado por líneas discontinuas (`--------------------`).
- El código debe ser lo más claro posible, de forma que casi no necesite comentarios adicionales.
- Se generan pruebas unitarias o de integración para todas las funciones y métodos importantes. Las pruebas se hacen con Jest.
- No se añaden funcionalidades que no estén en este diseño ni se cambia la arquitectura del sistema.
